<?php $title = 'Moova Pro'; ?>

<div style="padding-top: 35vh"></div>

<img src="/assets/logo.svg" id="logo-home">

<style>body{ background-image: url('<?= thumbnail_url(cockpit('regions:region_field', 'Home', 'img', 'value'), 2000, 800); ?>'); }</style>