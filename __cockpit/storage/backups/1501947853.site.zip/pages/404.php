<?php $title = 'Erreur 404 // Moova Pro'; ?>

<div style="padding-top: 25vh"></div>

<div class="container">
	<div class="row">
		<div class="col-md-6 col-md-offset-3 text-center">
			<div class="well">
				<h1>Erreur 404</h1>
				<p>La page que vous cherchez n'existe pas</p>
			</div>
		</div>
	</div>
</div>

<style>main{ background-image: url('/assets/motifs.svg'); background-color: #132b2d; }</style>