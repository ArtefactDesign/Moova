<?php $title = 'Présentation // Moova Pro'; ?>

<div class="visible-md-block visible-lg-block" style="padding-top: 25vh"></div>
<div class="visible-xs-block" style="padding-top: 10vh"></div>

<div class="container">
	<div class="row">
		<div class="col-md-4 col-md-offset-8">
			<div class="well text-justify">
				<?= cockpit('regions:region_field', 'Présentation', 'text', 'value'); ?>
			</div>
		</div>
	</div>
</div>

<style>body{ background-image: url('<?= thumbnail_url(cockpit('regions:region_field', 'Présentation', 'img', 'value'), 2000, 800); ?>'); }</style>