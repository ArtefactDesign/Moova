<?php session_start();	
require_once('cockpit/bootstrap.php');
require_once('lib/modele.php');
require_once('lib/route.php');