<?php require_once('lib/lib.php'); ?>

<!DOCTYPE HTML>
<html lang="fr">
<head>
	<meta http-equiv="Content-Type" content="text/html;charset=UTF-8"/>	
	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0" />
	<title><?= get_title(get_page($_GET['get'])); ?></title>
	<!-- LIB -->
	<script type="text/javascript" src="http://code.jquery.com/jquery-1.11.1.min.js"></script>
	<!-- BOOTSRAP -->
	<script type="text/javascript" src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css" />
	<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css" />
	<!-- CUSTOM -->
	<link rel="stylesheet" href="/assets/style.css">
</head>
<body id="body-page-<?= get_page($_GET['get']); ?>">
	
<header>
	<div class="container">
		<div class="row">
			<div class="col-md-2 visible-md-block visible-lg-block">
				<a href="/"><img src="/assets/logo.svg" id="logo"></a>				
			</div>
			<div class="col-md-10 col-xs-12">
				<nav class="navbar navbar-default">
					<div class="navbar-header">
						<div class="visible-xs-block col-xs-4">
							<a href="/"><img src="/assets/logo.svg"></a>				
						</div>							
						<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#main_nav" aria-expanded="false">
							<span class="sr-only">Toggle navigation</span>
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
						</button>
					</div>
					
					<div class="collapse navbar-collapse" id="main_nav">
						<ul class="nav navbar-nav navbar-right">
							<li <?php if(get_page($_GET['get'])=='presentation'){ echo 'class="active"'; } ?>>
								<a href="/presentation">PRÉSENTATION</a>
							</li>
							<li <?php if(get_page($_GET['get'])=='realisations'){ echo 'class="active"'; } ?>>
								<a href="/realisations">RÉALISATION</a>
							</li>
							<li <?php if(get_page($_GET['get'])=='contact'){ echo 'class="active"'; } ?>>
								<a href="/contact">CONTACT</a>
							</li>
							<li <?php if(get_page($_GET['get'])=='projet'){ echo 'class="active"'; } ?>>
								<a href="/projet"><span id="btn_projet"><span>VOTRE PROJET<br>SUR MESURE</span></span></a>
							</li>
							<li id="rs">
								<a href="<?= cockpit('regions:region_field', 'Réseaux sociaux', 'fb', 'value'); ?>" target="_blank">
									<i class="fa fa-facebook" aria-hidden="true"></i>
								</a>
								<a href="<?= cockpit('regions:region_field', 'Réseaux sociaux', 'ig', 'value'); ?>" target="_blank">
									<i class="fa fa-instagram" aria-hidden="true"></i>
								</a>
								<a href="<?= cockpit('regions:region_field', 'Réseaux sociaux', 'pt', 'value'); ?>" target="_blank">
									<i class="fa fa-pinterest-p" aria-hidden="true"></i>
								</a>
							</li>
						</ul>
					</div>
				</nav>
			</div>
		</div>
	</div>
</header>
	
<main>	
	<?= get_view(get_page($_GET['get'])); ?>
</main>

<footer class="visible-md-block visible-lg-block">
	<div class="container">
		<div class="row">
			<div class="col-md-2">
				<a data-toggle="collapse" href="#collapseMarques" aria-expanded="false" aria-controls="collapseMarques" id="partenaires_marques">PARTENAIRES <i class="fa fa-angle-double-right" aria-hidden="true"></i></a>
			</div>
			<div class="col-md-8 text-center">
				<div class="row">
					<?php foreach(collection("Marques")->find()->limit(6)->sort(['custom-order'=>1]) as $marques): ?>
						<a href="<?= $marques['url']; ?>" class="col-md-2 text-center"><?= thumbnail($marques["img"]);?></a>					
					<?php endforeach;?>
					<div class="collapse" id="collapseMarques">
					<?php foreach(collection("Marques")->find()->limit(99)->skip(6)->sort(['custom-order'=>1]) as $marques): ?>
						<a href="<?= $marques['url']; ?>" class="col-md-2 text-center"><?= thumbnail($marques["img"]);?></a>					
					<?php endforeach;?>
					</div>
				</div>
			</div>
			<div class="col-md-2 text-right">
				<a href="/mentions-legales">Mentions Légales</a>
			</div>
		</div>
	</div>
</footer>	

<script type="text/javascript" src="/assets/script.js"></script>

</body>
</html>